# Kai's Quest Converter

Unity editor tool for VRChat avatars. Open it from **Tools > Kai's Quest Converter**.

Tabs: Convert Materials, Remove PhysBones, Remove Incompatible, Check Quest.

Editor-only. Components are matched by type name, so it does not depend on a specific VRChat SDK version.
