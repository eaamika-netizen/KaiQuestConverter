// ============================================================================
//  Kai's Quest Converter  -  VRChat avatar -> Quest/Android helper
//  Menu: Tools > Kai's Quest Converter

using System.Collections.Generic;
using System.IO;
using System.Linq;
using UnityEditor;
using UnityEngine;

namespace KaiTools.QuestConverter
{
    // ------------------------------------------------------------------------
    //  Limits  (Excellent / Good / Medium / Poor ; anything above = Very Poor)
    // ------------------------------------------------------------------------
    internal static class QuestLimits
    {
        public static readonly int[] Triangles     = { 7500, 10000, 15000, 20000 };
        public static readonly int[] SkinnedMeshes = { 1, 1, 2, 2 };
        public static readonly int[] BasicMeshes   = { 1, 1, 2, 2 };
        public static readonly int[] MaterialSlots = { 1, 1, 2, 4 };
        public static readonly int[] Bones         = { 75, 90, 150, 150 };

        public static readonly string[] RankNames = { "Excellent", "Good", "Medium", "Poor", "Very Poor" };

        public static int RankOf(int value, int[] limits)
        {
            for (int i = 0; i < limits.Length; i++)
                if (value <= limits[i]) return i;
            return 4;
        }

        public static string Describe(int[] limits)
        {
            return string.Join(" / ", limits.Select(l => l.ToString("N0")).ToArray());
        }
    }

    // ------------------------------------------------------------------------
    //  Shared helpers
    // ------------------------------------------------------------------------
    internal static class QuestUtil
    {
        public static readonly HashSet<string> AllowedComponentNames = new HashSet<string>
        {
            "Transform", "Animator",
            "SkinnedMeshRenderer", "MeshRenderer", "MeshFilter",
            "AudioSource", "ParticleSystem", "ParticleSystemRenderer",
            "VRCAvatarDescriptor", "PipelineManager",
            "VRCPhysBone", "VRCPhysBoneCollider",
            "VRCContactSender", "VRCContactReceiver",
            "VRCHeadChop", "VRCSpatialAudioSource", "VRC_SpatialAudioSource",
            "ParentConstraint", "PositionConstraint", "RotationConstraint",
            "ScaleConstraint", "AimConstraint", "LookAtConstraint",
            "VRCParentConstraint", "VRCPositionConstraint", "VRCRotationConstraint",
            "VRCScaleConstraint", "VRCAimConstraint", "VRCLookAtConstraint"
        };

        public static readonly string[] BuildTimeNamespacePrefixes =
        {
            "nadena.dev", "VF.", "VRCFury", "com.vrcfury", "Anatawa12", "com.anatawa12"
        };

        public static bool HasDescriptor(GameObject go)
        {
            if (go == null) return false;
            foreach (var c in go.GetComponents<Component>())
                if (c != null && c.GetType().Name == "VRCAvatarDescriptor") return true;
            return false;
        }

        public static string Validate(GameObject go)
        {
            if (go == null) return "Drag your avatar from the scene Hierarchy into the Avatar field (or click Use Selection).";
            if (!go.scene.IsValid()) return "That's a project asset/prefab. Drag the avatar instance from the scene Hierarchy instead.";
            if (!HasDescriptor(go)) return "'" + go.name + "' has no VRC Avatar Descriptor on its root. Select the avatar's root object.";
            return null;
        }

        public static string Sanitize(string s)
        {
            foreach (var ch in Path.GetInvalidFileNameChars()) s = s.Replace(ch, '_');
            return s.Trim();
        }

        public static string BaseName(GameObject go)
        {
            string n = go.name;
            if (n.EndsWith("(Clone)")) n = n.Substring(0, n.Length - 7).Trim();
            if (n.EndsWith("_Quest")) n = n.Substring(0, n.Length - 6);
            return Sanitize(n);
        }

        public static string PathOf(Transform t, Transform root)
        {
            var parts = new List<string>();
            for (var cur = t; cur != null; cur = cur.parent)
            {
                parts.Add(cur.name);
                if (cur == root) break;
            }
            parts.Reverse();
            return string.Join("/", parts.ToArray());
        }

        public static bool IsEditorOnly(Transform t, Transform root)
        {
            for (var cur = t; cur != null; cur = cur.parent)
            {
                if (cur.CompareTag("EditorOnly")) return true;
                if (cur == root) break;
            }
            return false;
        }

        public static bool IsPhysBone(Component c)         { return c != null && c.GetType().Name == "VRCPhysBone"; }
        public static bool IsPhysBoneCollider(Component c) { return c != null && c.GetType().Name == "VRCPhysBoneCollider"; }

        public static bool IsQuestShader(Shader s)
        {
            return s != null && s.name.StartsWith("VRChat/Mobile/");
        }

        public const string ToonStandardShader = "VRChat/Mobile/Toon Standard";

        public static Dictionary<Material, List<Renderer>> MaterialUsage(GameObject root)
        {
            var d = new Dictionary<Material, List<Renderer>>();
            foreach (var r in root.GetComponentsInChildren<Renderer>(true))
            {
                if (IsEditorOnly(r.transform, root.transform)) continue;
                foreach (var m in r.sharedMaterials)
                {
                    if (m == null) continue;
                    List<Renderer> l;
                    if (!d.TryGetValue(m, out l)) { l = new List<Renderer>(); d[m] = l; }
                    if (!l.Contains(r)) l.Add(r);
                }
            }
            return d;
        }

        static void CopyTexture(Material src, Material dst, string[] srcProps, string dstProp)
        {
            if (!dst.HasProperty(dstProp)) return;
            foreach (var p in srcProps)
            {
                if (!src.HasProperty(p)) continue;
                Texture tex = null;
                try { tex = src.GetTexture(p); } catch { }
                if (tex == null) continue;
                dst.SetTexture(dstProp, tex);
                dst.SetTextureScale(dstProp, src.GetTextureScale(p));
                dst.SetTextureOffset(dstProp, src.GetTextureOffset(p));
                return;
            }
        }

        static void CopyColor(Material src, Material dst, string[] srcProps, string dstProp)
        {
            if (!dst.HasProperty(dstProp)) return;
            foreach (var p in srcProps)
            {
                if (!src.HasProperty(p)) continue;
                try { dst.SetColor(dstProp, src.GetColor(p)); return; } catch { }
            }
        }

        public static Material CreateQuestMaterial(Material src, Shader target, string folder)
        {
            var dst = new Material(target);
            dst.name = src.name + "_Q";

            CopyTexture(src, dst, new[] { "_MainTex", "_BaseMap", "_BaseColorMap", "_BaseTex", "_Albedo", "_Diffuse", "_DiffuseMap" }, "_MainTex");
            CopyColor(src, dst, new[] { "_Color", "_BaseColor", "_MainColor", "_TintColor" }, "_Color");
            CopyTexture(src, dst, new[] { "_BumpMap", "_NormalMap", "_NormalTex" }, "_BumpMap");
            CopyTexture(src, dst, new[] { "_EmissionMap", "_EmissiveTex" }, "_EmissionMap");
            CopyColor(src, dst, new[] { "_EmissionColor", "_EmissiveColor" }, "_EmissionColor");

            if (dst.HasProperty("_EmissionMap") && dst.GetTexture("_EmissionMap") != null &&
                dst.HasProperty("_EmissionColor") && dst.GetColor("_EmissionColor").maxColorComponent <= 0f)
                dst.SetColor("_EmissionColor", Color.white);

            string path = AssetDatabase.GenerateUniqueAssetPath(folder + "/" + Sanitize(dst.name) + ".mat");
            AssetDatabase.CreateAsset(dst, path);
            return dst;
        }

        public static bool IsCompatible(Component c)
        {
            var t = c.GetType();
            if (AllowedComponentNames.Contains(t.Name)) return true;
            string ns = t.Namespace ?? "";
            foreach (var p in BuildTimeNamespacePrefixes)
                if (ns.StartsWith(p)) return true;
            return false;
        }

        public static List<Component> FindIncompatible(GameObject root, out List<GameObject> missingOn)
        {
            var res = new List<Component>();
            missingOn = new List<GameObject>();
            foreach (var t in root.GetComponentsInChildren<Transform>(true))
            {
                if (IsEditorOnly(t, root.transform)) continue;
                bool hasMissing = false;
                foreach (var c in t.GetComponents<Component>())
                {
                    if (c == null) { hasMissing = true; continue; }
                    if (!IsCompatible(c)) res.Add(c);
                }
                if (hasMissing) missingOn.Add(t.gameObject);
            }
            return res;
        }

        public static int CountMissing(List<GameObject> gos)
        {
            int n = 0;
            foreach (var g in gos) n += GameObjectUtility.GetMonoBehavioursWithMissingScriptCount(g);
            return n;
        }

        public static bool IsRequiredByOther(Component c)
        {
            var ct = c.GetType();
            foreach (var o in c.gameObject.GetComponents<Component>())
            {
                if (o == null || o == c) continue;
                var attrs = System.Attribute.GetCustomAttributes(o.GetType(), typeof(RequireComponent), true);
                foreach (var a in attrs)
                {
                    var rc = (RequireComponent)a;
                    if (Req(rc.m_Type0, ct) || Req(rc.m_Type1, ct) || Req(rc.m_Type2, ct)) return true;
                }
            }
            return false;
        }

        static bool Req(System.Type required, System.Type candidate)
        {
            return required != null && required.IsAssignableFrom(candidate);
        }
    }

    // ------------------------------------------------------------------------
    //  Quest compatibility analysis
    // ------------------------------------------------------------------------
    internal enum Severity { Error, Warning, Info }

    internal class Issue
    {
        public Severity Sev;
        public string Text;
        public Object Target;
    }

    internal class StatRow
    {
        public string Name;
        public int Value;
        public int Rank;
        public string Limits;
    }

    internal class Report
    {
        public List<Issue> Issues = new List<Issue>();
        public List<StatRow> Stats = new List<StatRow>();
        public int OverallRank;
        public bool Works { get { return !Issues.Any(i => i.Sev == Severity.Error); } }

        public void Add(Severity s, string text, Object target = null)
        {
            Issues.Add(new Issue { Sev = s, Text = text, Target = target });
        }
    }

    internal static class QuestChecker
    {
        static int TriCount(Mesh m)
        {
            int n = 0;
            for (int i = 0; i < m.subMeshCount; i++)
                if (m.GetTopology(i) == MeshTopology.Triangles)
                    n += (int)(m.GetIndexCount(i) / 3);
            return n;
        }

        static void AddStat(Report rep, string name, int value, int[] limits)
        {
            rep.Stats.Add(new StatRow
            {
                Name = name,
                Value = value,
                Rank = QuestLimits.RankOf(value, limits),
                Limits = QuestLimits.Describe(limits)
            });
        }

        public static Report Analyze(GameObject avatar)
        {
            var rep = new Report();
            var root = avatar.transform;

            if (EditorUserBuildSettings.activeBuildTarget != BuildTarget.Android)
                rep.Add(Severity.Info, "Unity's build target is " + EditorUserBuildSettings.activeBuildTarget +
                    ". Switch to Android in the VRChat SDK Control Panel > Builder before building the Quest version.");

            // ---- components --------------------------------------------------
            List<GameObject> missingOn;
            var bad = QuestUtil.FindIncompatible(avatar, out missingOn);
            foreach (var c in bad)
                rep.Add(Severity.Error, "Incompatible component '" + c.GetType().Name + "' on " +
                    QuestUtil.PathOf(c.transform, root) + "   -> use the 'Remove Incompatible' tab", c.gameObject);
            foreach (var g in missingOn)
                rep.Add(Severity.Error, g.name + " has " + GameObjectUtility.GetMonoBehavioursWithMissingScriptCount(g) +
                    " missing script(s)   -> use the 'Remove Incompatible' tab", g);

            // ---- materials / shaders ----------------------------------------
            var usage = QuestUtil.MaterialUsage(avatar);
            foreach (var kv in usage)
            {
                if (QuestUtil.IsQuestShader(kv.Key.shader)) continue;
                string sh = kv.Key.shader != null ? kv.Key.shader.name : "(missing shader)";
                rep.Add(Severity.Error, "Material '" + kv.Key.name + "' uses unsupported shader '" + sh + "' (" +
                    kv.Value.Count + " renderer(s))   -> use the 'Convert Materials' tab", kv.Key);
            }

            foreach (var r in avatar.GetComponentsInChildren<Renderer>(true))
            {
                if (QuestUtil.IsEditorOnly(r.transform, root)) continue;
                if (r.sharedMaterials.Any(m => m == null))
                    rep.Add(Severity.Warning, "Empty material slot on " + QuestUtil.PathOf(r.transform, root), r.gameObject);
            }

            // ---- textures ----------------------------------------------------
            var seenTex = new HashSet<Texture>();
            foreach (var mat in usage.Keys)
            {
                var sh = mat.shader;
                if (sh == null) continue;
                int n = ShaderUtil.GetPropertyCount(sh);
                for (int i = 0; i < n; i++)
                {
                    if (ShaderUtil.GetPropertyType(sh, i) != ShaderUtil.ShaderPropertyType.TexEnv) continue;
                    var tex = mat.GetTexture(ShaderUtil.GetPropertyName(sh, i));
                    if (tex == null || !seenTex.Add(tex)) continue;
                    if (Mathf.Max(tex.width, tex.height) > 2048)
                        rep.Add(Severity.Warning, "Texture '" + tex.name + "' is " + tex.width + "x" + tex.height +
                            ". Big textures eat into the 10 MB Android avatar download limit - consider 1024-2048 max.", tex);
                }
            }

            // ---- mesh stats ---------------------------------------------------
            int tris = 0, skinned = 0, basic = 0, slots = 0;
            bool unreadable = false;
            var bones = new HashSet<Transform>();
            foreach (var r in avatar.GetComponentsInChildren<Renderer>(true))
            {
                if (QuestUtil.IsEditorOnly(r.transform, root)) continue;
                Mesh m = null;
                var smr = r as SkinnedMeshRenderer;
                if (smr != null)
                {
                    skinned++;
                    m = smr.sharedMesh;
                    foreach (var b in smr.bones) if (b != null) bones.Add(b);
                    slots += smr.sharedMaterials.Length;
                }
                else if (r is MeshRenderer)
                {
                    basic++;
                    var mf = r.GetComponent<MeshFilter>();
                    m = mf != null ? mf.sharedMesh : null;
                    slots += r.sharedMaterials.Length;
                }
                else continue;

                if (m != null)
                {
                    if (!m.isReadable)
                    {
                        unreadable = true;
                        rep.Add(Severity.Warning, "Mesh '" + m.name + "' has Read/Write disabled - VRChat ranks the avatar Very Poor when that happens.", m);
                    }
                    tris += TriCount(m);
                }
            }

            AddStat(rep, "Triangles", tris, QuestLimits.Triangles);
            AddStat(rep, "Skinned Meshes", skinned, QuestLimits.SkinnedMeshes);
            AddStat(rep, "Basic Meshes", basic, QuestLimits.BasicMeshes);
            AddStat(rep, "Material Slots", slots, QuestLimits.MaterialSlots);
            AddStat(rep, "Bones", bones.Count, QuestLimits.Bones);

            rep.OverallRank = rep.Stats.Max(s => s.Rank);
            if (unreadable) rep.OverallRank = 4;

            foreach (var s in rep.Stats)
                if (s.Rank >= 3)
                    rep.Add(s.Rank >= 4 ? Severity.Warning : Severity.Info,
                        s.Name + ": " + s.Value.ToString("N0") + " (limits " + s.Limits + ") -> " + QuestLimits.RankNames[s.Rank]);

            if (rep.OverallRank >= 4)
                rep.Add(Severity.Error, "Overall rank on Android would be Very Poor. VRChat may refuse the upload and other Quest users will not see the avatar. " +
                    "Reduce triangles / meshes / material slots / bones.");
            else if (rep.OverallRank == 3)
                rep.Add(Severity.Warning, "Overall rank is Poor. Mobile users' default minimum displayed rank is Medium, so many people will see a fallback instead of your avatar.");

            // ---- Avatar Dynamics (info only) ------------------------------------
            int pb = 0, pbc = 0, contacts = 0, constraints = 0;
            foreach (var c in avatar.GetComponentsInChildren<Component>(true))
            {
                if (c == null) continue;
                string n = c.GetType().Name;
                if (n == "VRCPhysBone") pb++;
                else if (n == "VRCPhysBoneCollider") pbc++;
                else if (n == "VRCContactSender" || n == "VRCContactReceiver") contacts++;
                else if (n.EndsWith("Constraint")) constraints++;
            }
            if (pb + pbc + contacts + constraints > 0)
                rep.Add(Severity.Info, "Avatar Dynamics: " + pb + " PhysBone(s), " + pbc + " collider(s), " + contacts +
                    " contact(s), " + constraints + " constraint(s). Android has its own limits for these - if exceeded, VRChat strips ALL of them. " +
                    "Use the 'Remove PhysBones' tab if you'd rather drop them.");

            rep.Add(Severity.Info, "The compressed avatar must be under 10 MB for Android. Check the real size in the VRChat SDK Control Panel after a build.");

            return rep;
        }
    }

    // ------------------------------------------------------------------------
    //  Main window
    // ------------------------------------------------------------------------
    public class KaiQuestConverter : EditorWindow
    {
        static readonly string[] TabNames = { "Convert Materials", "Remove PhysBones", "Remove Incompatible", "Check Quest" };

        GameObject avatar, lastAvatar;
        int tab, lastTab = -1;

        Dictionary<Material, List<Renderer>> matUsage;
        Vector2 matScroll;

        bool includeColliders;
        bool showFullPaths;
        bool pbDirty = true;
        Dictionary<Transform, int> pbCount = new Dictionary<Transform, int>();
        Dictionary<Transform, int> colCount = new Dictionary<Transform, int>();
        Dictionary<Transform, List<Transform>> subtreeOwners = new Dictionary<Transform, List<Transform>>();
        HashSet<Transform> pbSelected = new HashSet<Transform>();
        HashSet<Transform> collapsed = new HashSet<Transform>();
        Transform pendingFold;
        Vector2 pbScroll;

        List<Component> badComponents;
        List<GameObject> missingOn;
        Vector2 badScroll;

        [MenuItem("Tools/Kai's Quest Converter")]
        static void Open()
        {
            var w = GetWindow<KaiQuestConverter>("Kai's Quest Converter");
            w.minSize = new Vector2(480, 560);
            w.Show();
        }

        void OnEnable()
        {
            if (avatar == null && QuestUtil.Validate(Selection.activeGameObject) == null)
                avatar = Selection.activeGameObject;
        }

        void InvalidateCaches()
        {
            matUsage = null;
            pbDirty = true;
            badComponents = null;
            missingOn = null;
        }

        // ---------------------------------------------------------------- GUI
        void OnGUI()
        {
            GUILayout.Space(4);
            bool valid = DrawAvatarField();

            if (avatar != lastAvatar || tab != lastTab)
            {
                lastAvatar = avatar;
                lastTab = tab;
                InvalidateCaches();
            }

            GUILayout.Space(4);
            tab = GUILayout.Toolbar(tab, TabNames, GUILayout.Height(26));
            GUILayout.Space(6);

            if (!valid) return;

            switch (tab)
            {
                case 0: DrawConvertTab(); break;
                case 1: DrawPhysBoneTab(); break;
                case 2: DrawIncompatibleTab(); break;
                case 3: DrawCheckTab(); break;
            }
        }

        bool DrawAvatarField()
        {
            EditorGUILayout.BeginHorizontal();
            avatar = (GameObject)EditorGUILayout.ObjectField("Avatar", avatar, typeof(GameObject), true);
            if (GUILayout.Button("Use Selection", GUILayout.Width(100)) && Selection.activeGameObject != null)
                avatar = Selection.activeGameObject;
            EditorGUILayout.EndHorizontal();

            string err = QuestUtil.Validate(avatar);
            if (err != null)
            {
                EditorGUILayout.HelpBox(err, MessageType.Warning);
                return false;
            }
            return true;
        }

        // ------------------------------------------------------- TAB 1: materials
        void DrawConvertTab()
        {
            string baseName = QuestUtil.BaseName(avatar);
            EditorGUILayout.HelpBox(
                "Creates  Assets/Materials_" + baseName + "_QMaterials  and swaps every material that isn't a VRChat Mobile shader for a new copy using VRChat/Mobile/Toon Standard " +
                "(main texture, colour, normal map and emission are carried over).", MessageType.Info);

            if (matUsage == null) matUsage = QuestUtil.MaterialUsage(avatar);

            int need = matUsage.Keys.Count(m => !QuestUtil.IsQuestShader(m.shader));
            EditorGUILayout.Space();
            EditorGUILayout.BeginHorizontal();
            EditorGUILayout.LabelField("Materials: " + matUsage.Count + "   |   Need converting: " + need, EditorStyles.boldLabel);
            if (GUILayout.Button("Refresh", GUILayout.Width(70))) matUsage = QuestUtil.MaterialUsage(avatar);
            EditorGUILayout.EndHorizontal();

            matScroll = EditorGUILayout.BeginScrollView(matScroll, EditorStyles.helpBox, GUILayout.ExpandHeight(true));
            foreach (var kv in matUsage.OrderBy(k => QuestUtil.IsQuestShader(k.Key.shader)).ThenBy(k => k.Key.name))
            {
                bool ok = QuestUtil.IsQuestShader(kv.Key.shader);
                EditorGUILayout.BeginHorizontal();
                var prev = GUI.color;
                GUI.color = ok ? new Color(0.6f, 1f, 0.6f) : new Color(1f, 0.6f, 0.6f);
                GUILayout.Label(ok ? "OK" : "CONVERT", EditorStyles.miniBoldLabel, GUILayout.Width(60));
                GUI.color = prev;
                GUILayout.Label(new GUIContent(kv.Key.name, kv.Key.shader != null ? kv.Key.shader.name : "(missing shader)"));
                GUILayout.FlexibleSpace();
                GUILayout.Label(kv.Key.shader != null ? kv.Key.shader.name : "(missing)", EditorStyles.miniLabel);
                if (GUILayout.Button("Ping", EditorStyles.miniButton, GUILayout.Width(40))) EditorGUIUtility.PingObject(kv.Key);
                EditorGUILayout.EndHorizontal();
            }
            EditorGUILayout.EndScrollView();

            using (new EditorGUI.DisabledScope(need == 0))
            {
                var prevBg = GUI.backgroundColor;
                GUI.backgroundColor = new Color(0.5f, 0.85f, 1f);
                if (GUILayout.Button("CONVERT MATERIALS TO QUEST", GUILayout.Height(34)))
                {
                    ConvertMaterials();
                    GUIUtility.ExitGUI();
                }
                GUI.backgroundColor = prevBg;
            }
            GUILayout.Space(4);
        }

        void ConvertMaterials()
        {
            var shader = Shader.Find(QuestUtil.ToonStandardShader);
            if (shader == null)
            {
                EditorUtility.DisplayDialog("Shader not found",
                    "Couldn't find '" + QuestUtil.ToonStandardShader + "'. Make sure the VRChat Avatars SDK (with its Mobile shaders) is imported.", "OK");
                return;
            }

            string baseName = QuestUtil.BaseName(avatar);
            GameObject target = avatar;

            string folderName = "Materials_" + baseName + "_QMaterials";
            string folder = "Assets/" + folderName;
            if (!AssetDatabase.IsValidFolder(folder)) AssetDatabase.CreateFolder("Assets", folderName);

            int converted = 0;
            try
            {
                var usage = QuestUtil.MaterialUsage(target);
                var map = new Dictionary<Material, Material>();
                int i = 0;
                foreach (var kv in usage)
                {
                    i++;
                    EditorUtility.DisplayProgressBar("Converting materials", kv.Key.name, i / (float)usage.Count);
                    if (QuestUtil.IsQuestShader(kv.Key.shader)) continue;

                    map[kv.Key] = QuestUtil.CreateQuestMaterial(kv.Key, shader, folder);
                    converted++;
                }

                foreach (var r in target.GetComponentsInChildren<Renderer>(true))
                {
                    var mats = r.sharedMaterials;
                    bool changed = false;
                    for (int j = 0; j < mats.Length; j++)
                    {
                        Material nm;
                        if (mats[j] != null && map.TryGetValue(mats[j], out nm)) { mats[j] = nm; changed = true; }
                    }
                    if (changed)
                    {
                        Undo.RecordObject(r, "Kai Quest: convert materials");
                        r.sharedMaterials = mats;
                        EditorUtility.SetDirty(r);
                    }
                }
            }
            finally
            {
                EditorUtility.ClearProgressBar();
            }

            AssetDatabase.SaveAssets();
            AssetDatabase.Refresh();
            UnityEditor.SceneManagement.EditorSceneManager.MarkSceneDirty(target.scene);

            InvalidateCaches();
            EditorGUIUtility.PingObject(AssetDatabase.LoadAssetAtPath<Object>(folder));

            EditorUtility.DisplayDialog("Done",
                "Converted " + converted + " material(s) on '" + target.name + "'.\nSaved in: " + folder +
                "\n\n(Ctrl+Z undoes the material swap on the avatar.)", "OK");
        }

        // ------------------------------------------------------- TAB 2: physbones
        void RefreshPhysBones()
        {
            pbCount.Clear();
            colCount.Clear();
            subtreeOwners.Clear();
            pbSelected.Clear();

            foreach (var c in avatar.GetComponentsInChildren<Component>(true))
            {
                if (QuestUtil.IsPhysBone(c))
                {
                    int n; pbCount.TryGetValue(c.transform, out n); pbCount[c.transform] = n + 1;
                }
                else if (includeColliders && QuestUtil.IsPhysBoneCollider(c))
                {
                    int n; colCount.TryGetValue(c.transform, out n); colCount[c.transform] = n + 1;
                }
            }
            BuildSubtree(avatar.transform);
            pbDirty = false;
        }

        List<Transform> BuildSubtree(Transform t)
        {
            var list = new List<Transform>();
            if (pbCount.ContainsKey(t) || colCount.ContainsKey(t)) list.Add(t);
            for (int i = 0; i < t.childCount; i++) list.AddRange(BuildSubtree(t.GetChild(i)));
            if (list.Count > 0) subtreeOwners[t] = list;
            return list;
        }

        void DrawPhysBoneTab()
        {
            if (pbDirty) RefreshPhysBones();

            EditorGUILayout.HelpBox(
                "Every object that holds a PhysBone is listed with all of its parents. Tick the ones you want (ticking a parent ticks everything under it), " +
                "then press DELETE PHYSBONES at the bottom.", MessageType.Info);

            EditorGUILayout.BeginHorizontal();
            EditorGUI.BeginChangeCheck();
            includeColliders = GUILayout.Toggle(includeColliders, "Include PhysBone Colliders");
            showFullPaths = GUILayout.Toggle(showFullPaths, "Show full paths");
            if (EditorGUI.EndChangeCheck()) pbDirty = true;
            GUILayout.FlexibleSpace();
            if (GUILayout.Button("Refresh", GUILayout.Width(70))) pbDirty = true;
            EditorGUILayout.EndHorizontal();

            var owners = subtreeOwners.ContainsKey(avatar.transform)
                ? subtreeOwners[avatar.transform] : new List<Transform>();

            EditorGUILayout.BeginHorizontal();
            EditorGUILayout.LabelField("PhysBone objects found: " + owners.Count + "   |   Selected: " + pbSelected.Count, EditorStyles.boldLabel);
            if (GUILayout.Button("Select All", GUILayout.Width(80))) foreach (var o in owners) pbSelected.Add(o);
            if (GUILayout.Button("Select None", GUILayout.Width(80))) pbSelected.Clear();
            EditorGUILayout.EndHorizontal();

            pbScroll = EditorGUILayout.BeginScrollView(pbScroll, EditorStyles.helpBox, GUILayout.ExpandHeight(true));
            if (owners.Count == 0)
                GUILayout.Label("No PhysBones found on this avatar.", EditorStyles.centeredGreyMiniLabel);
            else
                DrawNode(avatar.transform, 0);
            EditorGUILayout.EndScrollView();

            if (pendingFold != null)
            {
                if (!collapsed.Remove(pendingFold)) collapsed.Add(pendingFold);
                pendingFold = null;
                Repaint();
            }

            using (new EditorGUI.DisabledScope(pbSelected.Count == 0))
            {
                var prevBg = GUI.backgroundColor;
                GUI.backgroundColor = new Color(1f, 0.4f, 0.4f);
                if (GUILayout.Button("DELETE PHYSBONES  (" + pbSelected.Count + " object(s))", GUILayout.Height(36)))
                {
                    DeletePhysBones();
                    GUIUtility.ExitGUI();
                }
                GUI.backgroundColor = prevBg;
            }
            GUILayout.Space(4);
        }

        void DrawNode(Transform t, int depth)
        {
            List<Transform> list;
            if (!subtreeOwners.TryGetValue(t, out list)) return;

            bool hasKids = false;
            for (int i = 0; i < t.childCount; i++)
                if (subtreeOwners.ContainsKey(t.GetChild(i))) { hasKids = true; break; }

            EditorGUILayout.BeginHorizontal();
            GUILayout.Space(depth * 14);

            Rect fr = GUILayoutUtility.GetRect(14, 16, GUILayout.Width(14));
            if (hasKids)
            {
                bool open = !collapsed.Contains(t);
                if (EditorGUI.Foldout(fr, open, GUIContent.none, true) != open) pendingFold = t;
            }

            int sel = list.Count(x => pbSelected.Contains(x));
            bool all = sel == list.Count;
            EditorGUI.showMixedValue = sel > 0 && !all;
            EditorGUI.BeginChangeCheck();
            EditorGUILayout.Toggle(all, GUILayout.Width(16));
            if (EditorGUI.EndChangeCheck())
            {
                if (all) foreach (var x in list) pbSelected.Remove(x);
                else foreach (var x in list) pbSelected.Add(x);
            }
            EditorGUI.showMixedValue = false;

            int pc, cc;
            pbCount.TryGetValue(t, out pc);
            colCount.TryGetValue(t, out cc);
            string full = QuestUtil.PathOf(t, avatar.transform);
            string label = showFullPaths ? full : t.name;
            if (pc > 0) label += "   [PhysBone" + (pc > 1 ? " x" + pc : "") + "]";
            if (cc > 0) label += "   [Collider" + (cc > 1 ? " x" + cc : "") + "]";
            bool isOwner = pc > 0 || cc > 0;
            GUILayout.Label(new GUIContent(label, full), isOwner ? EditorStyles.boldLabel : EditorStyles.label);

            GUILayout.FlexibleSpace();
            if (GUILayout.Button("Ping", EditorStyles.miniButton, GUILayout.Width(40)))
            {
                EditorGUIUtility.PingObject(t.gameObject);
                Selection.activeGameObject = t.gameObject;
            }
            EditorGUILayout.EndHorizontal();

            if (!collapsed.Contains(t))
                for (int i = 0; i < t.childCount; i++) DrawNode(t.GetChild(i), depth + 1);
        }

        void DeletePhysBones()
        {
            if (!EditorUtility.DisplayDialog("Delete PhysBones",
                "Delete the PhysBone component(s) on " + pbSelected.Count + " object(s)?\n\nYou can undo this with Ctrl+Z.",
                "Delete", "Cancel")) return;

            Undo.IncrementCurrentGroup();
            Undo.SetCurrentGroupName("Kai Quest: delete PhysBones");
            int group = Undo.GetCurrentGroup();

            int removed = 0;
            foreach (var t in pbSelected.ToList())
            {
                if (t == null) continue;
                foreach (var c in t.GetComponents<Component>())
                {
                    if (QuestUtil.IsPhysBone(c) || (includeColliders && QuestUtil.IsPhysBoneCollider(c)))
                    {
                        Undo.DestroyObjectImmediate(c);
                        removed++;
                    }
                }
            }
            Undo.CollapseUndoOperations(group);
            UnityEditor.SceneManagement.EditorSceneManager.MarkSceneDirty(avatar.scene);
            pbDirty = true;

            EditorUtility.DisplayDialog("Done", "Removed " + removed + " component(s). (Ctrl+Z to undo)", "OK");
        }

        // ------------------------------------------------------- TAB 3: incompatible
        void ScanIncompatible()
        {
            badComponents = QuestUtil.FindIncompatible(avatar, out missingOn);
        }

        void DrawIncompatibleTab()
        {
            if (badComponents == null) ScanIncompatible();

            EditorGUILayout.HelpBox(
                "Finds every component Quest doesn't allow (lights, cameras, colliders, rigidbodies, cloth, UI, missing scripts, etc.) and removes them all at once. " +
                "Afterwards a window opens where you can undo each removal individually.\n" +
                "PhysBones, contacts and constraints are left alone here - use the PhysBones tab for those.", MessageType.Info);

            int missing = QuestUtil.CountMissing(missingOn);
            EditorGUILayout.BeginHorizontal();
            EditorGUILayout.LabelField("Incompatible components: " + badComponents.Count + "   |   Missing scripts: " + missing, EditorStyles.boldLabel);
            if (GUILayout.Button("Rescan", GUILayout.Width(70))) ScanIncompatible();
            EditorGUILayout.EndHorizontal();

            badScroll = EditorGUILayout.BeginScrollView(badScroll, EditorStyles.helpBox, GUILayout.ExpandHeight(true));
            if (badComponents.Count == 0 && missing == 0)
                GUILayout.Label("Nothing incompatible found.", EditorStyles.centeredGreyMiniLabel);

            foreach (var c in badComponents)
            {
                if (c == null) continue;
                EditorGUILayout.BeginHorizontal();
                GUILayout.Label(c.GetType().Name, EditorStyles.boldLabel, GUILayout.Width(150));
                GUILayout.Label(QuestUtil.PathOf(c.transform, avatar.transform));
                GUILayout.FlexibleSpace();
                if (GUILayout.Button("Ping", EditorStyles.miniButton, GUILayout.Width(40))) EditorGUIUtility.PingObject(c.gameObject);
                EditorGUILayout.EndHorizontal();
            }
            foreach (var g in missingOn)
            {
                if (g == null) continue;
                EditorGUILayout.BeginHorizontal();
                GUILayout.Label("Missing script", EditorStyles.boldLabel, GUILayout.Width(150));
                GUILayout.Label(QuestUtil.PathOf(g.transform, avatar.transform));
                GUILayout.FlexibleSpace();
                if (GUILayout.Button("Ping", EditorStyles.miniButton, GUILayout.Width(40))) EditorGUIUtility.PingObject(g);
                EditorGUILayout.EndHorizontal();
            }
            EditorGUILayout.EndScrollView();

            using (new EditorGUI.DisabledScope(badComponents.Count == 0 && missing == 0))
            {
                var prevBg = GUI.backgroundColor;
                GUI.backgroundColor = new Color(1f, 0.4f, 0.4f);
                if (GUILayout.Button("REMOVE ALL INCOMPATIBLE", GUILayout.Height(36)))
                {
                    RemoveIncompatible();
                    GUIUtility.ExitGUI();
                }
                GUI.backgroundColor = prevBg;
            }
            GUILayout.Space(4);
        }

        void RemoveIncompatible()
        {
            ScanIncompatible();
            if (!EditorUtility.DisplayDialog("Remove incompatible",
                "Remove " + badComponents.Count + " component(s) and any missing scripts from '" + avatar.name + "'?\n\n" +
                "You'll get a window afterwards to undo each removal.", "Remove", "Cancel")) return;

            Undo.IncrementCurrentGroup();
            Undo.SetCurrentGroupName("Kai Quest: remove incompatible");
            int group = Undo.GetCurrentGroup();

            var records = new List<RemovedRecord>();
            var pending = new List<Component>(badComponents);

            bool progress = true;
            while (pending.Count > 0 && progress)
            {
                progress = false;
                foreach (var c in pending.ToList())
                {
                    if (c == null) { pending.Remove(c); continue; }
                    if (QuestUtil.IsRequiredByOther(c)) continue;

                    var rec = new RemovedRecord
                    {
                        Go = c.gameObject,
                        Type = c.GetType(),
                        Json = EditorJsonUtility.ToJson(c),
                        Path = QuestUtil.PathOf(c.transform, avatar.transform)
                    };
                    Undo.DestroyObjectImmediate(c);
                    records.Add(rec);
                    pending.Remove(c);
                    progress = true;
                }
            }

            var failed = pending.Where(c => c != null)
                .Select(c => c.GetType().Name + " on " + QuestUtil.PathOf(c.transform, avatar.transform)).ToList();

            int missingRemoved = 0;
            foreach (var g in missingOn)
            {
                if (g == null) continue;
                missingRemoved += GameObjectUtility.RemoveMonoBehavioursWithMissingScript(g);
            }

            Undo.CollapseUndoOperations(group);
            UnityEditor.SceneManagement.EditorSceneManager.MarkSceneDirty(avatar.scene);
            badComponents = null;

            RemovedWindow.ShowResults(records, missingRemoved, failed);
        }

        // ------------------------------------------------------- TAB 4: check
        void DrawCheckTab()
        {
            EditorGUILayout.HelpBox(
                "Scans the avatar for everything that would stop it working on Quest (shaders, components, missing scripts, mesh/material/bone counts, textures) " +
                "and opens a report telling you what's wrong and whether it will work.", MessageType.Info);

            GUILayout.FlexibleSpace();
            var prevBg = GUI.backgroundColor;
            GUI.backgroundColor = new Color(0.5f, 1f, 0.6f);
            if (GUILayout.Button("CHECK IF AVATAR WILL WORK ON QUEST", GUILayout.Height(44)))
            {
                ReportWindow.ShowFor(avatar);
                GUIUtility.ExitGUI();
            }
            GUI.backgroundColor = prevBg;
            GUILayout.Space(8);
        }
    }

    // ------------------------------------------------------------------------
    //  "Undo each removal" window
    // ------------------------------------------------------------------------
    internal class RemovedRecord
    {
        public GameObject Go;
        public System.Type Type;
        public string Json;
        public string Path;
        public bool Restored;
    }

    internal class RemovedWindow : EditorWindow
    {
        List<RemovedRecord> records;
        int missingRemoved;
        List<string> failed;
        Vector2 scroll;

        public static void ShowResults(List<RemovedRecord> recs, int missing, List<string> failedList)
        {
            var w = GetWindow<RemovedWindow>(true, "Removed Items - Undo", true);
            w.records = recs;
            w.missingRemoved = missing;
            w.failed = failedList;
            w.minSize = new Vector2(520, 360);
            w.Show();
            w.Repaint();
        }

        void OnGUI()
        {
            if (records == null)
            {
                GUILayout.Label("Nothing to show (the window was reloaded). Use Ctrl+Z in the scene to undo.");
                return;
            }

            EditorGUILayout.LabelField("Removed " + records.Count + " component(s)", EditorStyles.boldLabel);
            if (missingRemoved > 0)
                EditorGUILayout.HelpBox(missingRemoved + " missing script(s) were removed. Those have no data left, so they can't be restored.", MessageType.None);
            if (failed != null && failed.Count > 0)
                EditorGUILayout.HelpBox("Couldn't remove (another component needs them):\n" + string.Join("\n", failed.ToArray()), MessageType.Warning);

            scroll = EditorGUILayout.BeginScrollView(scroll, EditorStyles.helpBox, GUILayout.ExpandHeight(true));
            foreach (var r in records)
            {
                EditorGUILayout.BeginHorizontal();
                GUILayout.Label(r.Type.Name, EditorStyles.boldLabel, GUILayout.Width(150));
                GUILayout.Label(r.Path);
                GUILayout.FlexibleSpace();
                if (r.Restored)
                    GUILayout.Label("Restored", EditorStyles.miniLabel, GUILayout.Width(60));
                else if (GUILayout.Button("Undo", EditorStyles.miniButton, GUILayout.Width(60)))
                {
                    if (!Restore(r))
                        EditorUtility.DisplayDialog("Couldn't restore",
                            "Unity wouldn't re-add " + r.Type.Name + " to " + r.Path + ".", "OK");
                    GUIUtility.ExitGUI();
                }
                EditorGUILayout.EndHorizontal();
            }
            EditorGUILayout.EndScrollView();

            EditorGUILayout.BeginHorizontal();
            if (GUILayout.Button("Restore ALL", GUILayout.Height(28)))
            {
                foreach (var r in records.Where(x => !x.Restored).Reverse().ToList()) Restore(r);
                GUIUtility.ExitGUI();
            }
            if (GUILayout.Button("Close", GUILayout.Height(28))) Close();
            EditorGUILayout.EndHorizontal();
            GUILayout.Space(4);
        }

        static bool Restore(RemovedRecord r)
        {
            if (r.Go == null) return false;

            Component c = null;
            if (r.Type.IsDefined(typeof(DisallowMultipleComponent), true))
                c = r.Go.GetComponent(r.Type);
            if (c == null)
                c = Undo.AddComponent(r.Go, r.Type);
            if (c == null)
                c = r.Go.GetComponent(r.Type);
            if (c == null) return false;

            EditorJsonUtility.FromJsonOverwrite(r.Json, c);
            EditorUtility.SetDirty(c);
            r.Restored = true;
            return true;
        }
    }

    // ------------------------------------------------------------------------
    //  Quest report window
    // ------------------------------------------------------------------------
    internal class ReportWindow : EditorWindow
    {
        GameObject avatar;
        Report report;
        Vector2 scroll;

        public static void ShowFor(GameObject av)
        {
            var w = GetWindow<ReportWindow>(true, "Quest Compatibility Report", true);
            w.avatar = av;
            w.minSize = new Vector2(560, 520);
            w.Run();
            w.Show();
        }

        void Run()
        {
            if (avatar != null) report = QuestChecker.Analyze(avatar);
            Repaint();
        }

        static Color RankColor(int rank)
        {
            switch (rank)
            {
                case 0: return new Color(0.3f, 0.8f, 0.4f);
                case 1: return new Color(0.5f, 0.8f, 0.3f);
                case 2: return new Color(0.9f, 0.8f, 0.2f);
                case 3: return new Color(0.95f, 0.55f, 0.2f);
                default: return new Color(0.9f, 0.3f, 0.3f);
            }
        }

        static GUIStyle Colored(GUIStyle baseStyle, Color col, int size = 0)
        {
            var s = new GUIStyle(baseStyle);
            s.normal.textColor = col;
            if (size > 0) s.fontSize = size;
            return s;
        }

        void OnGUI()
        {
            if (avatar == null || report == null)
            {
                GUILayout.Label("No avatar to check. Use the 'Check Quest' tab in Kai's Quest Converter.");
                return;
            }

            bool ok = report.Works;
            int errors = report.Issues.Count(i => i.Sev == Severity.Error);
            int warns = report.Issues.Count(i => i.Sev == Severity.Warning);

            GUILayout.Space(6);
            GUILayout.Label(avatar.name, EditorStyles.centeredGreyMiniLabel);
            GUILayout.Label(ok ? "WILL WORK ON QUEST" : "WILL NOT WORK ON QUEST",
                Colored(EditorStyles.boldLabel, ok ? new Color(0.3f, 0.85f, 0.4f) : new Color(0.95f, 0.35f, 0.35f), 22),
                GUILayout.Height(34));
            GUILayout.Label(errors + " problem(s)   |   " + warns + " warning(s)   |   Estimated rank: " + QuestLimits.RankNames[report.OverallRank],
                EditorStyles.centeredGreyMiniLabel);
            GUILayout.Space(6);

            EditorGUILayout.BeginVertical(EditorStyles.helpBox);
            foreach (var s in report.Stats)
            {
                EditorGUILayout.BeginHorizontal();
                GUILayout.Label(s.Name, GUILayout.Width(120));
                GUILayout.Label(s.Value.ToString("N0"), EditorStyles.boldLabel, GUILayout.Width(70));
                GUILayout.Label("limits: " + s.Limits, EditorStyles.miniLabel);
                GUILayout.FlexibleSpace();
                GUILayout.Label(QuestLimits.RankNames[s.Rank], Colored(EditorStyles.boldLabel, RankColor(s.Rank)), GUILayout.Width(80));
                EditorGUILayout.EndHorizontal();
            }
            EditorGUILayout.EndVertical();

            GUILayout.Space(6);
            GUILayout.Label("What's wrong", EditorStyles.boldLabel);

            scroll = EditorGUILayout.BeginScrollView(scroll, GUILayout.ExpandHeight(true));
            if (report.Issues.Count == 0)
                GUILayout.Label("Nothing found.", EditorStyles.centeredGreyMiniLabel);

            foreach (var i in report.Issues.OrderBy(x => (int)x.Sev))
            {
                Color col; string tag;
                switch (i.Sev)
                {
                    case Severity.Error:   col = new Color(0.95f, 0.35f, 0.35f); tag = "ERROR"; break;
                    case Severity.Warning: col = new Color(0.95f, 0.7f, 0.2f);   tag = "WARN";  break;
                    default:               col = new Color(0.6f, 0.7f, 0.9f);    tag = "INFO";  break;
                }

                EditorGUILayout.BeginHorizontal(EditorStyles.helpBox);
                GUILayout.Label(tag, Colored(EditorStyles.boldLabel, col), GUILayout.Width(52));
                var wrap = new GUIStyle(EditorStyles.label) { wordWrap = true };
                GUILayout.Label(i.Text, wrap);
                if (i.Target != null && GUILayout.Button("Ping", EditorStyles.miniButton, GUILayout.Width(40)))
                {
                    EditorGUIUtility.PingObject(i.Target);
                    Selection.activeObject = i.Target;
                }
                EditorGUILayout.EndHorizontal();
            }
            EditorGUILayout.EndScrollView();

            EditorGUILayout.BeginHorizontal();
            if (GUILayout.Button("Re-check", GUILayout.Height(28))) Run();
            if (GUILayout.Button("Close", GUILayout.Height(28))) Close();
            EditorGUILayout.EndHorizontal();
            GUILayout.Space(4);
        }
    }
}